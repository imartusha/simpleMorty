package com.example.simplemorty.data.repository

import com.example.simplemorty.data.models.mapLocEntToLocations
import com.example.simplemorty.data.models.dto.mapToLocation
import com.example.simplemorty.data.network.RickAndMortyApi
import com.example.simplemorty.domain.models.Location
import com.example.simplemorty.domain.repository.LocationsRepository

class LocationsRepositoryImpl(
    private val rickAndMortyApi: RickAndMortyApi
)
    :LocationsRepository{
    override suspend fun getLocationById(id: Int) : Location{
        return mapToLocation(rickAndMortyApi.getLocationByIdFromApi(id))
    }

    override suspend fun getAllLocations(): List<Location> {
        return mapLocEntToLocations(rickAndMortyApi.getAllLocationFromApi().locations)
    }
}