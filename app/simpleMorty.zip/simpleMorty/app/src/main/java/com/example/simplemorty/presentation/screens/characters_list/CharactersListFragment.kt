package com.example.simplemorty.presentation.screens.characters_list

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.simplemorty.databinding.CharacterslistBinding
import com.example.simplemorty.presentation.adapter.CharactersAdapter
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel

class CharactersListFragment : Fragment() {

    private lateinit var fragmentCharactersBinding: CharacterslistBinding
    private val binding get() = fragmentCharactersBinding

    private val viewModel: CharactersViewModel by viewModel<CharactersViewModel>()

    private lateinit var adapter: CharactersAdapter
    private lateinit var navController: NavController

    private lateinit var layoutManager: LinearLayoutManager

    private var isLoading = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        fragmentCharactersBinding = CharacterslistBinding.inflate(
            inflater, container, false
        )
        return fragmentCharactersBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = findNavController()

        layoutManager = LinearLayoutManager(activity)

        adapter = CharactersAdapter(emptyList()) { characterProfile ->
            val action = CharactersListFragmentDirections
                .actionCharactersListFragmentToInfoFragment(characterProfile.id)
            findNavController().navigate(action)
        }

        val recyclerView = binding.rvCharacters
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter

        val btnScrollToTop = binding.btnScrollToTop
        btnScrollToTop.visibility = View.GONE // Скрываем кнопку изначально
        btnScrollToTop.setOnClickListener {
            recyclerView.smoothScrollToPosition(0)
        }

        val btnScrollDown = binding.btnScrollToBottom
        btnScrollDown.setOnClickListener {
            recyclerView.smoothScrollBy(0, 300)
        }

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val isAtTop = !recyclerView.canScrollVertically(-1)

                if (isAtTop) {
                    // Если список находится в верхней части, скрываем кнопку
                    btnScrollToTop.visibility = View.GONE
                } else {
                    // Если список прокручен вниз, показываем кнопку
                    btnScrollToTop.visibility = View.VISIBLE
                }

                val visibleItemCount = layoutManager.childCount
                val totalItemCount = layoutManager.itemCount
                val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()
                val lastVisible = layoutManager.findLastVisibleItemPosition()
                val endHasBeenReached: Boolean = lastVisible >= totalItemCount

                Log.i(
                    "1111111111111111111111",
                    "$isLoading , visibleItemCount =$visibleItemCount,totalItemCount=$totalItemCount,firstVisibleItemPosition =$firstVisibleItemPosition, $lastVisible = lastVisible "
                )

                if (totalItemCount > 0 && endHasBeenReached) {
                    Snackbar.make(requireView(), "Все данные загружены", Snackbar.LENGTH_SHORT)
                        .show()
                }

                if (!isLoading && (visibleItemCount + firstVisibleItemPosition) >= totalItemCount) {
                    Log.i("22222222222222", "Loading next page")
                    isLoading = true
                    viewModel.dispatch(IntentScreenCharacters.LoadNextPage)
                }
            }
        })

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state
                    .collect { characterProfileList ->
                        adapter.updateList(characterProfileList)
                        isLoading = false
                    }
            }
        }
        viewModel.dispatch(IntentScreenCharacters.GetAllCharacters(1))
    }
}
