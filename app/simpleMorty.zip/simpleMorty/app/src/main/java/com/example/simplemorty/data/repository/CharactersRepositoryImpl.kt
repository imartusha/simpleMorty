package com.example.simplemorty.data.repository

import android.util.Log
import androidx.paging.PagingData
import com.example.simplemorty.data.database.CharacterDao
import com.example.simplemorty.data.database.CharactersDataBase
import com.example.simplemorty.data.models.mapCharDtoToCharProfiles
import com.example.simplemorty.data.models.dto.mapFromDtoToCharacterProfile
import com.example.simplemorty.data.models.entity.CharacterEntity
import com.example.simplemorty.data.models.entity.mapFromEntityToCharacterProfile
import com.example.simplemorty.data.models.entity.mapToCharacterEntity
import com.example.simplemorty.data.models.mapCharEntityToCharProfiles
import com.example.simplemorty.data.models.mapToCharactersListEntity
import com.example.simplemorty.data.network.RickAndMortyApi
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.repository.CharactersRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class CharactersRepositoryImpl(
    private val rickAndMortyApi: RickAndMortyApi,
    private val characterDao: CharacterDao

) : CharactersRepository {

    override suspend fun getCharacterById(id: Int): CharacterProfile {
        val characterFromLocalDb = characterDao.getCharacterByIdFromDB(id = id)
        if (characterFromLocalDb != null) {
            return mapFromEntityToCharacterProfile(characterFromLocalDb)
        } else {
            val characterFromApi = rickAndMortyApi.getCharacterByIdFromApi(id)
            characterDao.insertCharacter(
                mapToCharacterEntity(
                    mapFromDtoToCharacterProfile(
                        characterFromApi
                    )
                )
            )
            return mapFromDtoToCharacterProfile(characterFromApi)
        }
    }

    override suspend fun getAllCharacters(page: Int): List<CharacterProfile> {
        return withContext(Dispatchers.IO) {
                val charactersFromApi = rickAndMortyApi.getAllCharactersFromApi(page)
                characterDao.insertAllCharacters(
                    mapToCharactersListEntity(
                        mapCharDtoToCharProfiles(
                            characters = charactersFromApi.characters
                        )
                    )
                )
                mapCharDtoToCharProfiles(characters = charactersFromApi.characters)
        }
    }

    override suspend fun getMultipleCharacters(characters: List<String>): List<CharacterProfile> {
        val charactersDTOList =
            rickAndMortyApi.getMultipleCharactersFromApi(getIdesCharactersList(characters))
        return mapCharDtoToCharProfiles(characters = charactersDTOList)
    }

//    override suspend fun getCharByIdFromLocalDb(id: Int): CharacterProfile {
//        return mapToCharacterProfile(characterDao.getCharacterByIdFromDB(id = id))
//    }

    override suspend fun getAllCharactersFromLocalDb(): List<CharacterProfile> {
        return mapCharEntityToCharProfiles(characterDao.getAllCharacters())
    }

    private fun getIdesCharactersList(characters: List<String>): List<Int> {
        val listCharacters: MutableList<Int> = mutableListOf()
        characters.forEach { it ->
            val characterId = it.substringAfterLast("/", "").toInt()
            if (characterId == 0) {
                Log.e("Except in Episodes", "Not found id")
            }
            listCharacters.add(characterId)
        }
        return listCharacters
    }
}