//package com.example.simplemorty.data.network
//
//import androidx.paging.PagingSource
//import androidx.paging.PagingState
//import com.example.simplemorty.data.database.CharactersDataBase
//import com.example.simplemorty.data.models.entity.CharacterEntity
//
//class CharacterPagingSource(
//    private val rickAndMortyApi: RickAndMortyApi,
//    private val charactersDataBase: CharactersDataBase
//) : PagingSource<Int, CharacterEntity>() {
//
//    override fun getRefreshKey(state: PagingState<Int, CharacterEntity>): Int? {
//        return null
//    }
//
//    override suspend fun load(params: LoadParams<Int>):
//            LoadResult<Int, CharacterEntity> {
//
//        return try {
//            val currentPage = params.key ?: 1
//            val response = rickAndMortyApi.getAllCharactersFromApi(currentPage)
//            val responseData = mutableListOf<CharacterEntity>()
//            val data = response.body()?.results ?: emptyList()
//            responseData.addAll(data)
//
//            LoadResult.Page(
//                data = responseData,
//                prevKey = if (currentPage == 1) null else -1,
//                nextKey = currentPage.plus(1)
//            )
//        } catch (e: Exception) {
//            LoadResult.Error(e)
//        }
//
//    }
//}