package com.example.simplemorty.di

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.room.Room
import com.example.simplemorty.data.database.CharacterDao
import com.example.simplemorty.data.database.CharactersDataBase
import com.example.simplemorty.data.database.MY_DATA_BASE
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import com.example.simplemorty.data.network.RickAndMortyApi
import com.example.simplemorty.data.repository.CharactersRepositoryImpl
import com.example.simplemorty.data.repository.EpisodesRepositoryImpl
import com.example.simplemorty.data.repository.LocationsRepositoryImpl
import com.example.simplemorty.domain.repository.CharactersRepository
import com.example.simplemorty.domain.repository.EpisodesRepository
import com.example.simplemorty.domain.repository.LocationsRepository
import com.example.simplemorty.domain.useCase.GetAllCharactersUseCase
import com.example.simplemorty.domain.useCase.GetAllEpisodesUseCase
import com.example.simplemorty.domain.useCase.GetAllLocationsUseCase
import com.example.simplemorty.domain.useCase.GetCharacterUseCase
import com.example.simplemorty.domain.useCase.GetCharactersListForInfoEpisode
import com.example.simplemorty.domain.useCase.GetInfoEpisodeByIdUseCase
import com.example.simplemorty.domain.useCase.GetInfoLocationByIdUseCase
import com.example.simplemorty.presentation.screens.characters_list.CharactersViewModel
import com.example.simplemorty.presentation.screens.episodes_list.EpisodesViewModel
import com.example.simplemorty.presentation.screens.character_info.InfoCharacterViewModel
import com.example.simplemorty.presentation.screens.episode_info.InfoEpisodeViewModel
import com.example.simplemorty.presentation.screens.locations_list.LocationsViewModel
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.context.GlobalContext
import org.koin.dsl.module
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

fun injectFeature() = loadFeature

private val loadFeature by lazy {
    GlobalContext.loadKoinModules(appModule)
}
val appModule = module {

    viewModel<CharactersViewModel> {
        CharactersViewModel(
            getAllCharactersUseCase = get()
        )
    }
    viewModel<EpisodesViewModel> {
        EpisodesViewModel(
            getInfoEpisodeByIdUseCase = get(),
            getAllEpisodes = get()
        )
    }
    viewModel<LocationsViewModel> {
        LocationsViewModel(
            getInfoLocationByIdUseCase = get(),
            getAllLocationsUseCase = get()
        )
    }
    viewModel<InfoCharacterViewModel> {
        InfoCharacterViewModel(
            getCharacterUseCase = get()
        )
    }
    viewModel<InfoEpisodeViewModel> {
        InfoEpisodeViewModel(
            getInfoEpisodeByIdUseCase = get(),
            getCharactersListForInfoEpisode = get()
        )
    }

    single {
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY

        OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .build()
    }

    single {
        Retrofit.Builder()
            .baseUrl("https://rickandmortyapi.com/api/")
            .client(get<OkHttpClient>())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    single {
        val retrofit: Retrofit = get()
        retrofit.create(RickAndMortyApi::class.java)
    }

    single<CharacterDao> {
        get<CharactersDataBase>()
            .getCharacterDao()
    }

    single<CharactersDataBase> {
        Room.databaseBuilder(
            androidContext(),
            CharactersDataBase::class.java,
            MY_DATA_BASE
        )
            .fallbackToDestructiveMigration()
            .build()
    }

//    single {
//        Pager(
//            config = PagingConfig(
//                pageSize = 10,
//                enablePlaceholders = false
//            ),
//            remoteMediator = { CharacterPagingSource(get(), get()) }, // Исправлено на использование invoke
//            pagingSourceFactory = { get<CharactersDataBase>().getCharacterDao().getAllCharacters() }
//        ).flow
//    }
    //Characters

    single<CharactersRepository> {
        CharactersRepositoryImpl(
            rickAndMortyApi = get(),
            characterDao = get()
        )
    }
    factory<GetCharacterUseCase> {
        GetCharacterUseCase(
            charactersRepository = get()
        )
    }
    factory<GetAllCharactersUseCase> {
        GetAllCharactersUseCase(
            charactersRepository = get()
        )
    }
    factory<GetCharactersListForInfoEpisode> {
        GetCharactersListForInfoEpisode(
            charactersRepository = get()
        )
    }
    //Locations
    single<LocationsRepository> {
        LocationsRepositoryImpl(
            rickAndMortyApi = get()
        )
    }
    factory<GetInfoLocationByIdUseCase> {
        GetInfoLocationByIdUseCase(
            locationsRepository = get()
        )
    }
    factory<GetAllLocationsUseCase> {
        GetAllLocationsUseCase(
            locationsRepository = get()
        )
    }
    //Episodes
    single<EpisodesRepository> {
        EpisodesRepositoryImpl(
            rickAndMortyApi = get()
        )
    }
    factory<GetInfoEpisodeByIdUseCase> {
        GetInfoEpisodeByIdUseCase(
            episodesRepository = get()
        )
    }
    factory<GetAllEpisodesUseCase> {
        GetAllEpisodesUseCase(
            episodesRepository = get()
        )
    }
}