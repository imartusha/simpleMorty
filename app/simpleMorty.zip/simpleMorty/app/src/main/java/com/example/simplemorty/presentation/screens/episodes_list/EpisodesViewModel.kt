package com.example.simplemorty.presentation.screens.episodes_list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simplemorty.domain.models.Episode
import com.example.simplemorty.domain.useCase.GetAllEpisodesUseCase
import com.example.simplemorty.domain.useCase.GetInfoEpisodeByIdUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch


class EpisodesViewModel(
    private val getInfoEpisodeByIdUseCase: GetInfoEpisodeByIdUseCase,
    private val getAllEpisodes: GetAllEpisodesUseCase
) : ViewModel() {

    private val _episodesListStateFlow = MutableStateFlow<List<Episode>>(emptyList())
    val episodesListStateFlow: StateFlow<List<Episode>> = _episodesListStateFlow

    fun dispatch(intentScreenEpisodes: IntentScreenEpisodes) {
        when (intentScreenEpisodes) {
//            is IntentScreenEpisodes.GetEpisode -> getEpisode(intentScreenEpisodes.id)
            is IntentScreenEpisodes.GetAllEpisodes -> getAllEpisodes()
            else -> Unit
        }
    }
    private fun clickOnCharacter(episode: Episode) : Int{
        return episode.id
    }
//    private fun getEpisode(id: Int) {
//        viewModelScope.launch {
//            val episode = getInfoEpisodeByIdUseCase.getInfoEpisode(id = id)
//            _episodeLiveData.postValue(episode)
//        }
//    }

    private fun getAllEpisodes() {
        viewModelScope.launch {
            val episodesList = getAllEpisodes.getAllEpisodes()
            _episodesListStateFlow.value = episodesList
        }
    }
}

sealed interface IntentScreenEpisodes {

    data class GetEpisode(val id: Int) : IntentScreenEpisodes
    data object GetAllEpisodes : IntentScreenEpisodes
}
