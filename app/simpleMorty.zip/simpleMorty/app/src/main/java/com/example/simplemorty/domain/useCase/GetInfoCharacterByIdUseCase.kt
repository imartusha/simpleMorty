package com.example.simplemorty.domain.useCase

import com.example.simplemorty.domain.repository.CharactersRepository

class GetInfoCharacterByIdUseCase (
    private val charactersRepository: CharactersRepository
) {
    suspend fun getInfoChar(){
        TODO()
    }
}