package com.example.simplemorty.domain.useCase

import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.repository.CharactersRepository

class GetCharactersListForInfoEpisode (
    private val charactersRepository: CharactersRepository
){
    suspend fun getCharactersListForInfo(charactersIdes: List<String>): List<CharacterProfile> {
        return charactersRepository.getMultipleCharacters(charactersIdes)
    }
}