package com.example.simplemorty.data.models.dto

import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Location
import com.example.simplemorty.domain.models.Homeland
import com.google.gson.annotations.SerializedName

//@Entity(tableName = "characters")
class CharacterDTO(
    val created: String,
    val episode: List<String>,
    val gender: String,
    val id: Int,
    val image: String,
    val location: Location,
    val name: String?,

    @SerializedName("origin")
    val homeland: Homeland?,

    val species: String,
    val status: String,
    val type: String,
    val url: String
)

internal fun mapFromDtoToCharacterProfile(characterDTO: CharacterDTO): CharacterProfile {
    return CharacterProfile(
        created = characterDTO.created,
        episode = characterDTO.episode,
        gender = characterDTO.gender,
        id = characterDTO.id,
        image = characterDTO.image,
        location = characterDTO.location,
        name = requireNotNull(characterDTO.name),
        homeland = requireNotNull(characterDTO.homeland),
        species = characterDTO.species,
        status = characterDTO.status,
        type = characterDTO.type,
        url = characterDTO.url
    )
}
internal fun mapToCharacterDTO(characterProfile: CharacterProfile): CharacterDTO {
    return CharacterDTO(
        created = characterProfile.created,
        episode = characterProfile.episode,
        gender = characterProfile.gender,
        id = characterProfile.id,
        image = characterProfile.image,
        location = characterProfile.location,
        name = characterProfile.name,
        homeland = characterProfile.homeland,
        species = characterProfile.species,
        status = characterProfile.status,
        type = characterProfile.type,
        url = characterProfile.url
    )
}





