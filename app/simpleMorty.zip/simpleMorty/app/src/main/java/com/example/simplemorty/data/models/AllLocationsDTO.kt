package com.example.simplemorty.data.models

import com.example.simplemorty.data.models.dto.LocationDTO
import com.example.simplemorty.data.models.dto.mapToLocation
import com.example.simplemorty.domain.models.Info
import com.example.simplemorty.domain.models.Location
import com.google.gson.annotations.SerializedName

class AllLocationsDTO(

    @SerializedName("info")
    val infoByAllLocations: Info,

    @SerializedName("results")
    val locations: List<LocationDTO>
)

fun mapLocEntToLocations(locations: List<LocationDTO>): List<Location> {
    return locations.map { location ->
        mapToLocation(location)
    }
}
