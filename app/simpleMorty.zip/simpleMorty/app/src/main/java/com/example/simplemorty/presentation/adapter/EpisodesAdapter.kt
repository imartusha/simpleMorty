package com.example.simplemorty.presentation.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.simplemorty.databinding.ItemEpisodeBinding
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Episode

class EpisodesAdapter(
    private val episodeList: List<Episode>,
    private val onClick: (Episode) -> Unit
) : RecyclerView.Adapter<EpisodesAdapter.EpisodeViewHolder>() {

    private lateinit var itemEpisodeBinding: ItemEpisodeBinding
    private val binding get() = itemEpisodeBinding

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): EpisodeViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        itemEpisodeBinding = ItemEpisodeBinding.inflate(inflater, parent, false)
        val view = binding.root
        return EpisodeViewHolder(binding, view)
    }

    override fun onBindViewHolder(holder: EpisodeViewHolder, position: Int) {

        val episode = episodeList[position]

        holder.textViewEpisodeName.text = episode.name
        holder.textViewAirDate.text = episode.airDate
        holder.textViewEpisodeNumber.text = episode.episode

        holder.itemView.setOnClickListener{
            onClick(episode)
        }
    }

    override fun getItemCount(): Int {
        return episodeList.size
    }

    class EpisodeViewHolder(
        binding: ItemEpisodeBinding,
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        val textViewEpisodeName = binding.textViewEpisodeName
        val textViewEpisodeNumber = binding.textViewEpisodeNumber
        val textViewAirDate = binding.textViewAirDate

    }
}