package com.example.simplemorty.domain.models

class Homeland(
    val name: String,
    val url: String
) {
}
