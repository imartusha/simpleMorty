package com.example.simplemorty.data.models

import com.example.simplemorty.data.models.dto.EpisodeDTO
import com.example.simplemorty.data.models.dto.mapToEpisode
import com.example.simplemorty.domain.models.Episode
import com.example.simplemorty.domain.models.Info
import com.google.gson.annotations.SerializedName


class AllEpisodesDTO (

    @SerializedName("info")
    val infoByAllEpisodes: Info,

    @SerializedName("results")
    val episodes: List<EpisodeDTO>
)

fun mapEpisodesEntToEpisodes(episodes: List<EpisodeDTO>): List<Episode> {
    return episodes.map { episode ->
        mapToEpisode(episode)
    }
}
