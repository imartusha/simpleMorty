package com.example.simplemorty.presentation.screens.main_activity

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {


}