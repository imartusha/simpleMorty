package com.example.simplemorty.domain.useCase

import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Episode
import com.example.simplemorty.domain.repository.EpisodesRepository

class GetAllEpisodesUseCase(
    val episodesRepository: EpisodesRepository
) {
    suspend fun getAllEpisodes(): List<Episode> {
        return episodesRepository.getAllEpisodes()
    }

}