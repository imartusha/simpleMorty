package com.example.simplemorty.data.models

import com.example.simplemorty.data.models.dto.CharacterDTO
import com.example.simplemorty.data.models.dto.mapFromDtoToCharacterProfile
import com.example.simplemorty.data.models.entity.CharacterEntity
import com.example.simplemorty.data.models.entity.mapFromDTOToCharacterEntity
import com.example.simplemorty.data.models.entity.mapFromEntityToCharacterProfile
import com.example.simplemorty.data.models.entity.mapToCharacterEntity
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Info
import com.google.gson.annotations.SerializedName

class AllCharactersDTO(

    @SerializedName("info")
    val infoByAllCharacters: Info,

    @SerializedName("results")
    val characters: List<CharacterDTO>
)

fun mapCharDtoToCharProfiles(characters: List<CharacterDTO>): List<CharacterProfile> {
    return characters.map { characterDTO ->
        mapFromDtoToCharacterProfile(characterDTO)
    }
}
fun mapCharEntityToCharProfiles(characters: List<CharacterEntity>): List<CharacterProfile> {
    return characters.map { characterEntity ->
        mapFromEntityToCharacterProfile(characterEntity)
    }
}
fun mapToCharactersListEntity(characters: List<CharacterProfile>):  List<CharacterEntity>{
    return characters.map { characterProfile ->
        mapToCharacterEntity(characterProfile)
    }
}
fun mapToCharactersListEntityFromDTO(characters: List<CharacterDTO>):  List<CharacterEntity>{
    return characters.map { characterDTO ->
        mapFromDTOToCharacterEntity(characterDTO)
    }
}