package com.example.simplemorty.domain.models

data class CharacterProfile(
    val created: String,
    val episode: List<String>,
    val gender: String,
    val id: Int,
    val image: String,
    val location: Location,
    val name: String,
    val homeland: Homeland,
    val species: String,
    val status: String,
    val type: String,
    val url: String
) {
}

