package com.example.simplemorty.presentation.screens.episode_info

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Episode
import com.example.simplemorty.domain.useCase.GetCharactersListForInfoEpisode
import com.example.simplemorty.domain.useCase.GetInfoEpisodeByIdUseCase
import com.example.simplemorty.utils.formatDateString
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class InfoEpisodeViewModel(
    private val getInfoEpisodeByIdUseCase: GetInfoEpisodeByIdUseCase,
    private val getCharactersListForInfoEpisode: GetCharactersListForInfoEpisode
) : ViewModel() {
    private val _state = MutableStateFlow(ScreenStateEpisode())
    val state: StateFlow<ScreenStateEpisode> = _state

    fun dispatch(intentScreenInfoEpisode: IntentScreenInfoEpisode) {
        when (intentScreenInfoEpisode) {
            is IntentScreenInfoEpisode.GetEpisode -> getEpisodeById(intentScreenInfoEpisode.id)
            else -> throw IllegalArgumentException("Unknown intent screen: $intentScreenInfoEpisode")
        }
    }

    private fun getEpisodeById(id: Int) {
        viewModelScope.launch {
            val episode = getInfoEpisodeByIdUseCase.getInfoEpisode(id = id)
            val characters = getListCharactersForEpisode(episode)
            _state.update { state ->
                updateEpisodeInfo(state, episode, characters)
            }
        }
    }

    private suspend fun getListCharactersForEpisode(episode: Episode): List<CharacterProfile> {
        return getCharactersListForInfoEpisode.getCharactersListForInfo(charactersIdes = episode.characters)
    }
}

private fun updateEpisodeInfo(
    state: ScreenStateEpisode,
    episode: Episode,
    characters: List<CharacterProfile> // Принимаем список персонажей
): ScreenStateEpisode {
    return state.copy(
        name = episode.name,
        episode = episode.episode,
        airDate = episode.airDate,
        created = episode.created.formatDateString(),
        characters = characters,
        url = episode.url
    )
}

data class ScreenStateEpisode(
    val name: String? = null,
    val episode: String? = null,
    val airDate: String? = null,
    val created: String? = null,
    val characters: List<CharacterProfile>? = null,
    val url: String? = null
)

sealed interface IntentScreenInfoEpisode {

    data class GetEpisode(val id: Int) : IntentScreenInfoEpisode
}