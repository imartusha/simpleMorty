package com.example.simplemorty.data.models.dto

import android.util.Log
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Episode
import com.google.gson.annotations.SerializedName

//@Entity(tableName = "episodes")
class EpisodeDTO(

    @SerializedName("air_date")
    val airDate: String,

    val characters: List<String>,
    val created: String,
    val episode: String,
    val id: Int,
    val name: String,
    val url: String
)

internal fun mapToEpisode(episodeDTO: EpisodeDTO): Episode {
    return Episode(
        airDate = episodeDTO.airDate,
        characters = episodeDTO.characters,
        created = episodeDTO.created,
        episode = episodeDTO.episode,
        id = episodeDTO.id,
        name = episodeDTO.name,
        url = episodeDTO.url
    )
}

internal fun mapToEpisodeEntity(episode: Episode): EpisodeDTO {
    return EpisodeDTO(
        airDate = episode.airDate,
        characters = episode.characters,
        created = episode.created,
        episode = episode.episode,
        id = episode.id,
        name = episode.name,
        url = episode.url
    )
}
