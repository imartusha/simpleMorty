package com.example.simplemorty.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.simplemorty.data.models.entity.CharacterEntity

const val MY_DATA_BASE = "my-database"

@Database(
    entities = [CharacterEntity::class],
    version = 1,
    exportSchema = true)

abstract class CharactersDataBase : RoomDatabase() {

    abstract fun getCharacterDao(): CharacterDao
}