package com.example.simplemorty.data.repository

import com.example.simplemorty.data.models.mapEpisodesEntToEpisodes
import com.example.simplemorty.data.models.dto.mapToEpisode
import com.example.simplemorty.data.network.RickAndMortyApi
import com.example.simplemorty.domain.models.Episode
import com.example.simplemorty.domain.repository.EpisodesRepository

class EpisodesRepositoryImpl(
    private val rickAndMortyApi: RickAndMortyApi
)
    :EpisodesRepository{

    override suspend fun getEpisodeById(id: Int):Episode {
        return mapToEpisode(rickAndMortyApi.getEpisodeByIdFromApi(id))
    }

    override suspend fun getAllEpisodes():List<Episode>{
        return mapEpisodesEntToEpisodes(rickAndMortyApi.getAllEpisodesFromApi().episodes)
    }

}
