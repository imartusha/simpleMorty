package com.example.simplemorty.presentation.screens.main_activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.fragment.NavHostFragment
import com.example.simplemorty.R
import com.example.simplemorty.databinding.ActivityMainBinding
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView


class MainActivity : AppCompatActivity() {

    private val navController by lazy {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navHostFragment.navController
    }

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navView: BottomNavigationView = binding.navView

       // setupActionBarWithNavController(navController)
        navView.setupWithNavController(navController)

        // Включение кнопки "назад" на тулбаре
        //supportActionBar!!.setDisplayHomeAsUpEnabled(true)

    }
    override fun onSupportNavigateUp() = findNavController(R.id.nav_host_fragment).navigateUp()


}