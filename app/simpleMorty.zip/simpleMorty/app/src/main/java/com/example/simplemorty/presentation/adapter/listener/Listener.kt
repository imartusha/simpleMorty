package com.example.simplemorty.presentation.adapter.listener

import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Episode

interface Listener{
    fun onClickOnCharacter(characterProfile: CharacterProfile)
    fun onClickOnEpisode(episode: Episode)
}