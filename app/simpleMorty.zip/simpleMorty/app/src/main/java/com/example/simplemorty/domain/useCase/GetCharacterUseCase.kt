package com.example.simplemorty.domain.useCase

import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.repository.CharactersRepository

class GetCharacterUseCase(
    private val charactersRepository: CharactersRepository
) {
    suspend fun getCharacterById(id: Int): CharacterProfile {
        return charactersRepository.getCharacterById(id = id)
    }
    suspend fun getMultipleCharactersById(characters: List<String>): List<CharacterProfile>{
        return charactersRepository.getMultipleCharacters(characters = characters)
    }
}