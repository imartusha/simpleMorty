package com.example.simplemorty.presentation.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.simplemorty.databinding.ItemCharacterBinding
import com.example.simplemorty.domain.models.CharacterProfile

class CharactersAdapter(
    private var characterList: List<CharacterProfile>,
    private val onClick: (CharacterProfile) -> Unit
) : RecyclerView.Adapter<CharactersAdapter.CharacterViewHolder>() {

    private val characterMutableList: MutableList<CharacterProfile> = characterList.toMutableList()

    private lateinit var itemCharacterBinding: ItemCharacterBinding
    private val binding get() = itemCharacterBinding

    override fun onCreateViewHolder(
        parent: ViewGroup, viewType: Int
    ): CharacterViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        itemCharacterBinding = ItemCharacterBinding.inflate(inflater, parent, false)
        val view = binding.root
        return CharacterViewHolder(binding, view)
    }

    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {

        val character = characterMutableList[position]

        holder.characterName.text = character.name
        holder.species.text = character.species
        holder.status.text = character.status

        Glide.with(holder.itemView.context)
            .load(character.image)
            .into(holder.imgChar)

        holder.itemView.setOnClickListener {
            onClick(character)
        }
    }

    override fun getItemCount(): Int {
        return characterMutableList.size
    }

    class CharacterViewHolder(
        binding: ItemCharacterBinding,
        itemView: View
    ) : RecyclerView.ViewHolder(itemView) {

        val characterName = binding.characterName
        val species = binding.species
        val status = binding.status
        val imgChar = binding.imgChar
    }

    fun updateList(newList: List<CharacterProfile>) {
        characterMutableList.addAll(newList)
        notifyDataSetChanged()
    }

    fun currentList(): List<CharacterProfile> {
        return characterMutableList
    }
}
