package com.example.simplemorty.domain.useCase

import android.util.Log
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.repository.CharactersRepository

class GetAllCharactersUseCase(
    private val charactersRepository: CharactersRepository
) {
    suspend fun getAllCharacters(page: Int): List<CharacterProfile> {
        if (page !in 1..42) Log.e("Pages", "page goes out of bounds ")
        return charactersRepository.getAllCharacters(page)
    }
//    suspend fun getAllCharFromDb(): List<CharacterProfile>{
//        if ( charactersRepository.getAllCharactersFromLocalDb().size == 826){
//            return charactersRepository.getAllCharactersFromLocalDb().size == 826
//        }
//    }
}