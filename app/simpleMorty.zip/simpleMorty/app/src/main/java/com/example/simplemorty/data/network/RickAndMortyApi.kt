package com.example.simplemorty.data.network

import com.example.simplemorty.data.models.AllCharactersDTO
import com.example.simplemorty.data.models.AllEpisodesDTO
import com.example.simplemorty.data.models.AllLocationsDTO
import com.example.simplemorty.data.models.dto.CharacterDTO
import com.example.simplemorty.data.models.dto.EpisodeDTO
import com.example.simplemorty.data.models.dto.LocationDTO
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface RickAndMortyApi {

    @GET("character/{character-id}")
    suspend fun getCharacterByIdFromApi(
        @Path("character-id") id: Int
    ): CharacterDTO

    @GET("character/{character-id}")
    suspend fun getMultipleCharactersFromApi(
        @Path("character-id") ids: List<Int>
    ): List<CharacterDTO>



    @GET("character/")
    suspend fun getAllCharactersFromApi(
        @Query("page") page: Int
    ):AllCharactersDTO

//    @GET("character")
//    suspend fun getAllCharactersFromApi(): AllCharactersDTO

    @GET("location/{location-id}")
    suspend fun getLocationByIdFromApi(
        @Path("location-id") id: Int
    ): LocationDTO

    @GET("location")
    suspend fun getAllLocationFromApi(): AllLocationsDTO

    @GET("episode/{episode-id}")
    suspend fun getEpisodeByIdFromApi(
        @Path("episode-id") id: Int
    ): EpisodeDTO

    @GET("episode")
    suspend fun getAllEpisodesFromApi(): AllEpisodesDTO
}