package com.example.simplemorty.presentation.screens.characters_list

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.useCase.GetAllCharactersUseCase
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch

class CharactersViewModel(

    private val getAllCharactersUseCase: GetAllCharactersUseCase,
) : ViewModel() {

    private val _state = MutableSharedFlow<List<CharacterProfile>>()
    val state get() = _state.asSharedFlow()

    private var currentPage = 0

    fun dispatch(intentScreenCharacters: IntentScreenCharacters) {
        when (intentScreenCharacters) {
            is IntentScreenCharacters.GetAllCharacters -> getAllCharacters(page = intentScreenCharacters.page)
            is IntentScreenCharacters.LoadNextPage -> loadNextPage()
            else -> Unit
        }
    }

    private fun getAllCharacters(page: Int) {
        viewModelScope.launch {
            if (page <= 42) {
                val characterProfileList = getAllCharactersUseCase.getAllCharacters(page = page)
                _state.emit(characterProfileList)
                currentPage = page
            } else {
                Log.d("getAllCharacters", "Reached end of list")
            }
        }
    }

    private fun loadNextPage() {
        val nextPage = currentPage + 1
        getAllCharacters(nextPage)
    }
}

sealed interface IntentScreenCharacters {

    data class GetAllCharacters(val page: Int) : IntentScreenCharacters
    data object LoadNextPage : IntentScreenCharacters
}