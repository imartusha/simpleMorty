package com.example.simplemorty.domain.repository

import com.example.simplemorty.domain.models.CharacterProfile
import com.example.simplemorty.domain.models.Episode
import com.example.simplemorty.domain.models.Location

interface CharactersRepository {

    //network
    suspend fun getCharacterById(id: Int): CharacterProfile
    suspend fun getAllCharacters(page: Int): List<CharacterProfile>
    suspend fun getMultipleCharacters(characters: List<String>): List<CharacterProfile>
    //room db
    //suspend fun getCharByIdFromLocalDb(id: Int): CharacterProfile
    suspend fun getAllCharactersFromLocalDb(): List<CharacterProfile>
}
interface EpisodesRepository {
    suspend fun getEpisodeById(id: Int): Episode
    suspend fun getAllEpisodes():List<Episode>
}
interface LocationsRepository {
    suspend fun getLocationById(id: Int): Location
    suspend fun getAllLocations():List<Location>
}